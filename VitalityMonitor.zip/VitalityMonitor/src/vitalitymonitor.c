#include <tizen.h>
#include <sensor.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "vitalitymonitor.h"

typedef struct appdata {
	Evas_Object *win;
	Evas_Object *conform;
	int width, height;
} appdata_s;

typedef struct vitaldata {
	int hr, nibp, spo2, hrComprehensive, nibpComprehensive, spo2Comprehensive;
};

struct vitaldata vitals = { 0, 0, 0 };

Evas_Object *naviframe;
Evas_Object *mainLayout, *vitalsLayout, *adviceLayout;
Evas_Object *label, *secondLabel, *thirdLabel;
int transition = 0, screen = 0;
char *host = "192.168.1.57";
int port = 5500;
bool supported = false;

#define TEXT_BUF_SIZE 256

/*
 * This method is invoked when the program is in client mode
 */
void udpClient() {
	struct sockaddr_in server;
	int s = 0, connectResult = 0;
	// create a socket
	if ((s = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		dlog_print(DLOG_DEBUG, "socketstream", "Could not create socket");
		exit(1);
	}

	// define a target
	memset(&server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	server.sin_addr.s_addr = inet_addr(host);
	if ((connectResult = connect(s, (struct sockaddr *) &server,
			sizeof(server))) < 0) {
		dlog_print(DLOG_DEBUG, "socketstream", "connect error");
		return;
	} else {
		const char* connectedMessage = "connected to server\n\r";
		elm_object_text_set(label, connectedMessage);
		//sendSensorMessage(ad, connectedMessage, strlen(connectedMessage));
	}
	//close(s); // deallocate the socket
}

void prepareLayoutBoxes() {
	// Overall Score Screen layout
	mainLayout = elm_box_add(naviframe);

	/* Label*/
	label = elm_label_add(mainLayout);
	//evas_object_resize(label, width, height / 3);
	//evas_object_move(label, 0, height / 3);
	evas_object_size_hint_weight_set(label, 0.3, EVAS_HINT_EXPAND);
	evas_object_show(label);
	elm_box_pack_start(mainLayout, label);

	//Vitals Screen layout
	vitalsLayout = elm_box_add(naviframe);
	/* Label*/
	secondLabel = elm_label_add(mainLayout);
	//evas_object_resize(secondLabel, width, height / 3);
	//evas_object_move(secondLabel, 0, height / 3);
//	evas_object_size_hint_weight_set(secondLabel, 0.3, EVAS_HINT_EXPAND);
//	evas_object_size_hint_align_set(secondLabel, EVAS_HINT_FILL, EVAS_HINT_FILL);
	evas_object_show(secondLabel);

	elm_box_pack_start(mainLayout, secondLabel);

	// Advice Screen layout
	adviceLayout = elm_box_add(naviframe);
	/* Label*/
	thirdLabel = elm_label_add(mainLayout);
	//evas_object_resize(thirdLabel, width, height / 3);
	//evas_object_move(thirdLabel, 0, height / 3);
//	evas_object_size_hint_weight_set(thirdLabel, 0.3, EVAS_HINT_EXPAND);
//	evas_object_size_hint_align_set(thirdLabel, EVAS_HINT_FILL, EVAS_HINT_FILL);
	evas_object_show(thirdLabel);

	elm_box_pack_start(mainLayout, thirdLabel);

}

void changeScreen(int screen) {
	prepareLayoutBoxes();

	switch (screen) {
	case 0:
		elm_naviframe_item_push(naviframe, "Vitality Monitor", NULL, NULL,
				mainLayout, NULL);
		break;
	case 1:
		elm_naviframe_item_push(naviframe, "Vitals", NULL, NULL, vitalsLayout,
		NULL);
		break;
	case 2:
		elm_naviframe_item_push(naviframe, "Advice", NULL, NULL, adviceLayout,
		NULL);
		break;
	}
}

static void update_watch(appdata_s *ad, watch_time_h watch_time, int ambient) {
	char watch_text[TEXT_BUF_SIZE];
	int hour24, minute, second;

	if (watch_time == NULL)
		return;

	watch_time_get_hour24(watch_time, &hour24);
	watch_time_get_minute(watch_time, &minute);
	watch_time_get_second(watch_time, &second);
	if (!ambient) {
		snprintf(watch_text, TEXT_BUF_SIZE,
				"<align=center>Overall Score<br/>%02d:%02d:%02d</align>", hour24,
				minute, second);
	} else {
		snprintf(watch_text, TEXT_BUF_SIZE,
				"<align=center>Overall Score<br/>%02d:%02d</align>", hour24,
				minute);
	}

	//elm_object_text_set(label, "<align=center><font_size=50>Hello Tizen</font/></align>");
	//elm_object_text_set(label, watch_text);
	elm_object_style_set(label, "marker");
	snprintf(watch_text, TEXT_BUF_SIZE, "<align=right><font_size=50>Heart Rate: %d</font></align>",
			vitals.hr);
	elm_object_text_set(secondLabel, watch_text);
	elm_object_style_set(secondLabel, "marker");
	snprintf(watch_text, TEXT_BUF_SIZE,
			"<align=center>Blood Pressure: %d</align>", vitals.nibp);
	elm_object_text_set(thirdLabel, watch_text);
	elm_object_style_set(thirdLabel, "marker");
}

static Evas_Event_Flags finger_tap_callback(void *data, void *event_info) {
	Elm_Gesture_Taps_Info *p = (Elm_Gesture_Taps_Info *) event_info;
	printf("N tap started <%p> x,y=<%d,%d> count=<%d> timestamp=<%d> \n",
			event_info, p->x, p->y, p->n, p->timestamp);
	dlog_print(DLOG_ERROR, "YallaHabibi",
			"N tap started <%p> x,y=<%d,%d> count=<%d> timestamp=<%d> \n",
			event_info, p->x, p->y, p->n, p->timestamp);

	screen++;
	if (screen > 2) {
		screen = 0;
	}
	changeScreen(screen);

	return EVAS_EVENT_FLAG_ON_HOLD;
}

void prepareGestureLayer(appdata_s *ad) {
	/* Gesture layer transparent object */
	Evas_Object *r = evas_object_rectangle_add(evas_object_evas_get(ad->win));
	evas_object_move(r, 0, 0);
	evas_object_color_set(r, 0, 0, 0, 0);
	elm_win_resize_object_add(ad->win, r);
	/* Gesture layer object */
	Evas_Object *g = elm_gesture_layer_add(ad->win);
	elm_gesture_layer_attach(g, r);
	evas_object_show(r);
	elm_gesture_layer_cb_set(g, ELM_GESTURE_N_TAPS, ELM_GESTURE_STATE_START,
			finger_tap_callback, NULL);
}

static void create_base_gui(appdata_s *ad, int width, int height) {
	int ret;
	watch_time_h watch_time = NULL;

	/* Window */
	ad->win = elm_win_util_standard_add("gesture_layer", "Gesture Layer");
	elm_win_autodel_set(ad->win, EINA_TRUE);
//	ret = watch_app_get_elm_win(&ad->win);
//	if (ret != APP_ERROR_NONE) {
//		dlog_print(DLOG_ERROR, LOG_TAG, "failed to get window. err = %d", ret);
//		return;
//	}

	evas_object_resize(ad->win, width, height);

	/* Conformant */
	ad->conform = elm_conformant_add(ad->win);
	evas_object_size_hint_weight_set(ad->conform, EVAS_HINT_EXPAND,
	EVAS_HINT_EXPAND);
	elm_win_resize_object_add(ad->win, ad->conform);
	evas_object_show(ad->conform);

	//new
	/* Variables for naviframe item push */
	const char *title_text = "Vitality Monitor";
	/* Recommended NULL, replace with elm_naviframe_prev_btn_auto_pushed_set() */
	Evas_Object *prev_btn = NULL;
	/* Recommended NULL */
	Evas_Object *next_btn = NULL;
	Evas_Object *empty_content = NULL;
	const char *item_style_default = NULL;
	const char *item_style_tabbar = "tabbar";

	naviframe = elm_naviframe_add(ad->conform);
	elm_naviframe_prev_btn_auto_pushed_set(naviframe, EINA_TRUE); /* since Tizen 2.4 */
	elm_object_content_set(ad->conform, naviframe);
	evas_object_show(naviframe);

	prepareGestureLayer(ad);
	prepareLayoutBoxes();

	/* Push a naviframe item (push 2 items in total to show the back button) */
	elm_naviframe_item_push(naviframe, title_text, prev_btn, next_btn,
			mainLayout, item_style_default);

	ret = watch_time_get_current_time(&watch_time);
	if (ret != APP_ERROR_NONE)
		dlog_print(DLOG_INFO, LOG_TAG, "failed to get current time. err = %d",
				ret);

	update_watch(ad, watch_time, 0);
	watch_time_delete(watch_time);

	/* Show window after base gui is set up */
	evas_object_show(ad->win);
}

/* Define callback */
void sensor_callback(sensor_h sensor, sensor_event_s events[], int events_count,
		void *user_data) {
	sensor_type_e type;
	sensor_get_type(sensor, &type);
	int i = 0;
	for (i = 0; i < events_count; i++) {
		if (type == SENSOR_PRESSURE) {
			unsigned long long timestamp = events[i].timestamp;
			vitals.nibp = (int) events[i].values[0];
		} else if (type == SENSOR_HRM) {
			unsigned long long timestamp = events[0].timestamp;
			vitals.hr = (int) events[i].values[0];
		} else if (type == SENSOR_TEMPERATURE) {
			unsigned long long timestamp = events[i].timestamp;
			//vitals.nibp = (int) events[0].values[0];
		}
	}
}

void acquireSensorData() {
	sensor_h sensor;
	sensor_listener_h listener;
	sensor_is_supported(SENSOR_PRESSURE, &supported);
	if (supported) {
		//listen for pressure
		sensor_get_default_sensor(SENSOR_PRESSURE, &sensor);
		sensor_create_listener(sensor, &listener);
		/* Set interval */
		sensor_listener_set_interval(listener, 100);
		/* Register callback */
		sensor_listener_set_events_cb(listener, sensor_callback, NULL);
		sensor_listener_start(listener);
	}

	sensor_is_supported(SENSOR_HRM, &supported);
	if (supported) {
		// listen for hr
		sensor_get_default_sensor(SENSOR_HRM, &sensor);
		sensor_create_listener(sensor, &listener);
		sensor_listener_set_interval(listener, 100);
		sensor_listener_set_events_cb(listener, sensor_callback, NULL);
		sensor_listener_start(listener);
	}

	sensor_is_supported(SENSOR_TEMPERATURE, &supported);
	if (supported) {
		// listen for temperature
		sensor_get_default_sensor(SENSOR_TEMPERATURE, &sensor);
		sensor_create_listener(sensor, &listener);
		sensor_listener_set_interval(listener, 100);
		sensor_listener_set_events_cb(listener, sensor_callback, NULL);
		sensor_listener_start(listener);
	}
}

static bool app_create(int width, int height, void *data) {
	/* Hook to take necessary actions before main event loop starts
	 Initialize UI resources and application's data
	 If this function returns true, the main loop of application starts
	 If this function returns false, the application is terminated */
	appdata_s *ad = data;
	ad->width = width;
	ad->height = height;
	acquireSensorData();
	create_base_gui(ad, width, height);
	udpClient();

	return true;
}

static void app_control(app_control_h app_control, void *data) {
	/* Handle the launch request. */
}

static void app_pause(void *data) {
	/* Take necessary actions when application becomes invisible. */
}

static void app_resume(void *data) {
	/* Take necessary actions when application becomes visible. */
}

static void app_terminate(void *data) {
	/* Release all resources. */
}

static void app_time_tick(watch_time_h watch_time, void *data) {
	/* Called at each second while your app is visible. Update watch UI. */
	appdata_s *ad = data;
	update_watch(ad, watch_time, 0);
}

static void app_ambient_tick(watch_time_h watch_time, void *data) {
	/* Called at each minute while the device is in ambient mode. Update watch UI. */
	appdata_s *ad = data;
	update_watch(ad, watch_time, 1);
}

static void app_ambient_changed(bool ambient_mode, void *data) {
	/* Update your watch UI to conform to the ambient mode */
}

static void watch_app_lang_changed(app_event_info_h event_info, void *user_data) {
	/*APP_EVENT_LANGUAGE_CHANGED*/
	char *locale = NULL;
	app_event_get_language(event_info, &locale);
	elm_language_set(locale);
	free(locale);
	return;
}

static void watch_app_region_changed(app_event_info_h event_info,
		void *user_data) {
	/*APP_EVENT_REGION_FORMAT_CHANGED*/
}

int main(int argc, char *argv[]) {
	appdata_s ad = { 0, };
	int ret = 0;

	watch_app_lifecycle_callback_s event_callback = { 0, };
	app_event_handler_h handlers[5] = {
	NULL, };

	event_callback.create = app_create;
	event_callback.terminate = app_terminate;
	event_callback.pause = app_pause;
	event_callback.resume = app_resume;
	event_callback.app_control = app_control;
	event_callback.time_tick = app_time_tick;
	event_callback.ambient_tick = app_ambient_tick;
	event_callback.ambient_changed = app_ambient_changed;

	watch_app_add_event_handler(&handlers[APP_EVENT_LANGUAGE_CHANGED],
			APP_EVENT_LANGUAGE_CHANGED, watch_app_lang_changed, &ad);
	watch_app_add_event_handler(&handlers[APP_EVENT_REGION_FORMAT_CHANGED],
			APP_EVENT_REGION_FORMAT_CHANGED, watch_app_region_changed, &ad);

	ret = watch_app_main(argc, argv, &event_callback, &ad);
	if (ret != APP_ERROR_NONE) {
		dlog_print(DLOG_ERROR, LOG_TAG, "watch_app_main() is failed. err = %d",
				ret);
	}

	return ret;
}

